/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import java.sql.*;
/**
 *
 * @author MuChiB
 */
public class Koneksi {
    private Connection koneksi = null;
    public Connection KoneksiDatabase() {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            koneksi= DriverManager.getConnection("jdbc:mysql:///surat","root","");
            
        }catch (ClassNotFoundException|SQLException e){
            System.out.println("Connection Error : " +e.getMessage());
        }
        return koneksi;
    }
}