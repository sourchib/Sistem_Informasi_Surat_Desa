package Model;
import static View.Penduduk.Beranda;
import static View.Penduduk.BtnBeranda;
import static View.Penduduk.BtnPermohonan;
import static View.Penduduk.Content;
import static View.Staf.BtnData;
import static View.Staf.BtnKeluar;
import static View.Staf.BtnLaporan;
import static View.Staf.BtnPelayan;
import static View.Staf.BtnSurat;
import static View.Staf.Contents;
import static View.Staf.SuratMasuk;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JPanel;
/**
 *
 * @author MuChiB
 */
public class MenuPanel {
    private final ArrayList <JPanel> SidebarMenu = new ArrayList<>();
    private final Color primaryColor = new Color(204,204,204);
    private final Color primaryColorHover = new Color(255,255,255); 
     //    Agar ketika di Run otomatis masuk ke menu Home.
    public void initBeranda(){
        setActivePanel(Content, Beranda);
    }    
    //    Agar ketika di Run otomatis masuk ke menu Home.
    public void initPanelSurat(){
        setActivePanel(Contents, SuratMasuk);       
    }
   
    public void setActivePanel(JPanel parentPanel, JPanel menupanel){
        parentPanel.removeAll();
        parentPanel.repaint();
        parentPanel.revalidate();
        parentPanel.add(menupanel);
        parentPanel.repaint();
        parentPanel.revalidate();   
    }
//    Untuk array List Menu. 
    public void setMenuPenduduk(){
        SidebarMenu.add(BtnBeranda);        
        SidebarMenu.add(BtnPermohonan);
    }
//    Untuk array List Menu. 
    public void setMenuStaf(){
        SidebarMenu.add(BtnSurat);        
        SidebarMenu.add(BtnData);
        SidebarMenu.add(BtnPelayan);
        SidebarMenu.add(BtnLaporan);
        SidebarMenu.add(BtnKeluar);
    }
    void setResetActiveMenu(){
        SidebarMenu.forEach(menu -> menu.setBackground(primaryColor));
    }
    
    public void setActiveMenu(JPanel SidebarMenu){
        setResetActiveMenu();
        SidebarMenu.setBackground(primaryColorHover);
    }
}
