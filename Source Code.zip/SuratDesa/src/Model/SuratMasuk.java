package Model;
import static View.Staf.TblSuratMasuk;
import java.sql.*;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;
/**
 *
 * @author MuChiB
 */
public class SuratMasuk {
    private String query;
    private ResultSet rs;
    private Statement stmt; 
    private PreparedStatement ptmt;
     
//Menampilkan data permohonan ke tabel surat masuk         
     public void SuratMasuk(){
         Koneksi kon = new Koneksi();
         Connection connect=kon.KoneksiDatabase();
         try{
            query="SELECT no_permohonan, jenis_surat, nik, nama, keperluan "
                    + "FROM tb_permohonan order by no_permohonan";
            ptmt=connect.prepareStatement(query);
            rs=ptmt.executeQuery();
            TblSuratMasuk.setModel(DbUtils.resultSetToTableModel(rs));
            ptmt.close();
            connect.close();
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Data Gagal ditampilkan");
        }
     }
    
//    Total jumlah Surat masuk diteremi
    public int TotSuratMasuk() {
        Koneksi koneksi = new Koneksi();
        Connection connection = koneksi.KoneksiDatabase();
        int id = 0;
        try {
            stmt = connection.createStatement();
            //ambil data
            query = "SELECT count(no_permohonan) FROM tb_permohonan";
            rs = stmt.executeQuery(query);
            ResultSetMetaData meta = rs.getMetaData();
            while (rs.next()) {
                id = rs.getInt(1);
            }
            stmt.close();
            connection.close();
        } catch (SQLException e) {
            System.out.println("Error : " + e.getMessage());
        }
        return id;
    }
}
