package Model;
import java.sql.*;
/*
 *
 * @author MuChiB
 */
public class DataPenduduk {
    private String query;
    private ResultSet rs;
    private Statement stmt;
//    cek status
    public static boolean s_into = true;
//    tambah data penduduk
    public void TambahData(int nik, String nama, String jk, String agama, String lahir,String tgl, String alamat, String pendidikan
                               , String status, int rt, int rw) {        
        Koneksi koneksi = new Koneksi();
        Connection connection = koneksi.KoneksiDatabase();
        try {
            stmt = connection.createStatement();
            query = "INSERT INTO tb_datapenduduk (nik, nama, kelamin, "
                    + "agama, tempat_lahir, tgl_lahir, alamat, pendidikan, status, rt, rw) "
                    + "VALUES ('"+nik+"', '"+ nama +"', '"+ jk +"', '"+ agama +"', '"+ lahir+"', '"+ tgl +"',"
                    + "'" +alamat +"', '"+ pendidikan +"','"+ status +"', '"+ rt+"', '"+ rw +"')";
            stmt.executeUpdate(query);
            stmt.close();
            connection.close();
            
        } catch (SQLException e) {
            System.out.println("Error : " + e.getMessage());
        }
    }
    
//    Edit data pendudukk
    public void EditData(int nik, String nama, String jk, String agama, String lahir, String tgl, String alamat, String pendidikan
                               , String status, int rt, int rw) {
        
        Koneksi koneksi = new Koneksi();
        Connection connection = koneksi.KoneksiDatabase();
        try {
            stmt = connection.createStatement();
            query = "UPDATE tb_datapenduduk SET "
                    + "nik = '" + nik + "', nama = '" + nama + "', kelamin = '" + jk + "', agama = '" + agama + "', "
                    + " tempat_lahir = '" + lahir + "', tgl_lahir = '" + tgl + "', alamat = '" + alamat + "', pendidikan = '" + pendidikan + "', "
                    +" status = '" + status + "', rt = '" + rt + "', rw = '" + rw + "' WHERE nik = '" + nik + "'";
            stmt.executeUpdate(query);
            stmt.close();
            connection.close();
            
        } catch (SQLException e) {
            System.out.println("Error : " + e.getMessage());
        }
    }
//Cari Data Penduduk
    public String [][]CariPenduduk(String nik){
        Koneksi kon = new Koneksi();
        Connection connect=kon.KoneksiDatabase();
        String data [][]=null;
        try{
            stmt=connect.createStatement();
            query="SELECT * FROM tb_datapenduduk where nik LIKE '%"+nik+"%' order by nik ";
            rs=stmt.executeQuery(query);
            ResultSetMetaData meta = rs.getMetaData();
            int jmlKolom = meta.getColumnCount();
            data=new String[1000][jmlKolom];
            int r=0;
            while(rs.next()){
                for (int c = 0; c < jmlKolom; c++) {
                    data[r][c]=rs.getString(c+1);                                        
                }
                r++;
            }
            int jmlBaris=r;
            String [][]tmparray=data;
            data=new String [jmlBaris][jmlKolom];
            for (r = 0; r < jmlBaris; r++) {
                for (int c = 0; c < jmlKolom; c++) {
                    data[r][c]=tmparray[r][c];
                }
            }
            stmt.close();
            connect.close();
        }catch(SQLException ex){
            System.out.println("Error : "+ex.getMessage());
        }
        return data;
    }    
    //get jumlah baris
    private int JumlahBaris(ResultSet res) {
        int totalBaris = 0;
        try {
            res.last();
            totalBaris = res.getRow();
            res.beforeFirst();
        } catch (SQLException ex) {
            return 0;
        }
        return totalBaris;
    }    
    //get id nik
    public int DataID(String nik) {
        Koneksi koneksi = new Koneksi();
        Connection connection = koneksi.KoneksiDatabase();
        int id = 0;
        try {
            stmt = connection.createStatement();
            //ambil data
            query = "SELECT nik FROM tb_datapenduduk "
                    + "WHERE nik='" + nik + "'";
            rs = stmt.executeQuery(query);
            ResultSetMetaData meta = rs.getMetaData();
            while (rs.next()) {
                id = rs.getInt(1);
            }
            stmt.close();
            connection.close();
        } catch (SQLException e) {
            System.out.println("Error : " + e.getMessage());
        }
        return id;
    }    
    //    get data penduduk berdasarkan nik  
    public String[][] DataPendudukID(int id) {
        Koneksi koneksi = new Koneksi();
        Connection connection = koneksi.KoneksiDatabase();
        String data[][] = null;
        try {
            stmt = connection.createStatement();
            //ambil data
            query = "SELECT nik, nama, kelamin, "
                    + "agama, ttl, alamat, pendidikan, status, rt, rw FROM tb_datapenduduk where nik= '"+id+"'";
            rs = stmt.executeQuery(query);
            ResultSetMetaData meta = rs.getMetaData();
            int jumlahBaris = JumlahBaris(rs);
            int jumlahKolom = meta.getColumnCount();
            data = new String[jumlahBaris][jumlahKolom];
            int r = 0;
            while (rs.next()) {
                for (int c = 0; c < jumlahKolom; c++) {
                    data[r][c] = rs.getString(c + 1);
                }
                r++;
            }
            stmt.close();
            connection.close();
        } catch (SQLException e) {
            System.out.println("Error : " + e.getMessage());
        }
        return data;
    }        
    //    hapus data penduduk
    public void HapusData(String nik){
        Koneksi kon = new Koneksi();
        Connection connect = kon.KoneksiDatabase();
        try{
            stmt=connect.createStatement();
            query="DELETE FROM tb_datapenduduk WHERE nik="+nik+"";
            stmt.executeUpdate(query);
            stmt.close();
            connect.close();
        }catch(SQLException ex){
            System.out.println("Error : "+ex.getMessage());
        }
    }    
    //    Total jumlah datapenduduk diteremi
    public int TotDataPenduduk() {
        Koneksi koneksi = new Koneksi();
        Connection connection = koneksi.KoneksiDatabase();
        int id = 0;
        try {
            stmt = connection.createStatement();
            //ambil data
            query = "SELECT count(nik) FROM tb_datapenduduk";
            rs = stmt.executeQuery(query);
            ResultSetMetaData meta = rs.getMetaData();
            while (rs.next()) {
                id = rs.getInt(1);
            }
            stmt.close();
            connection.close();
        } catch (SQLException e) {
            System.out.println("Error : " + e.getMessage());
        }
        return id;
    }   
        
}