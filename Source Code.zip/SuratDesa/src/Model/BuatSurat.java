package Model;
import static View.Staf.TBAgama;
import static View.Staf.TBAlamat;
import static View.Staf.TBJk;
import static View.Staf.TBKeperluan;
import static View.Staf.TBNama;
import static View.Staf.TBNoP;
import static View.Staf.TBtglL;
import static View.Staf.TBtptL;
import java.sql.*;
import static View.Staf.TBJenis;
import static View.Staf.TBNik;
/**
 *
 * @author MuChiB
 */
public class BuatSurat {
    private String query;
    private ResultSet rs;
    private Statement stmt;
    private PreparedStatement ptmt;    
//Cari Data Penduduk
    public void KeyDataPenduduk(){
        Koneksi kon = new Koneksi();        
        Connection connect=kon.KoneksiDatabase();
        try{
            query  = "SELECT d.nik, p.no_permohonan, p.jenis_surat, p.keperluan, d.nama, d.kelamin, d.tempat_lahir, d.tgl_lahir, d.agama, d.alamat "
                    + "FROM tb_datapenduduk AS d INNER JOIN tb_permohonan AS p ON p.nik=d.nik WHERE p.no_permohonan=?";
            ptmt = connect.prepareStatement(query);
            ptmt.setString(1, TBNoP.getText());
            rs = ptmt.executeQuery();
            if (rs.next()) {
                String setno = rs.getString("nik");                
                TBNik.setText(setno);
                String setsurat = rs.getString("jenis_surat");
                TBJenis.setText(setsurat);
                String setperlu = rs.getString("keperluan");
                TBKeperluan.setText(setperlu);
                String setnama = rs.getString("nama");
                TBNama.setText(setnama);
                String setkelamin = rs.getString("kelamin");
                TBJk.setText(setkelamin);
                String settmp = rs.getString("tempat_lahir");
                TBtptL.setText(settmp);
                String settgl = rs.getString("tgl_lahir");
                TBtglL.setText(settgl);
                String setagama = rs.getString("agama");
                TBAgama.setText(setagama);
                String setalamat = rs.getString("alamat");
                TBAlamat.setText(setalamat);
            }
            ptmt.close();
            connect.close();
        }catch(SQLException ex){
            System.out.println("Error : "+ex.getMessage());
        }
    }
    
    public void SimpanData(int no, int nik, String surat, String tglbuat,String keperluan) {
        Koneksi koneksi = new Koneksi();
        Connection connection = koneksi.KoneksiDatabase();
        try {
            stmt = connection.createStatement();
            query = "INSERT INTO tb_buatsurat (no_permohonan, nik, jenis_surat, tgl_buat, keperluan)"
                    + "VALUES ('"+no+"', '"+nik +"', '"+ surat+"', '"+ tglbuat+"', '"+ keperluan+"')";
            stmt.executeUpdate(query);
            stmt.close();
            connection.close();
        } catch (SQLException e) {
            System.out.println("Error : " + e.getMessage());
        }
    } 
        //    hapus data penduduk
    public void HapusSuratMasuk(int no){
        Koneksi kon = new Koneksi();
        Connection connect = kon.KoneksiDatabase();
        try{
            stmt=connect.createStatement();
            query="DELETE FROM tb_permohonan WHERE no_permohonan="+no+"";
            stmt.executeUpdate(query);
            stmt.close();
            connect.close();
        }catch(SQLException ex){
            System.out.println("Error : "+ex.getMessage());
        }
    } 
//    Hapus TextField 
    public void ClearTextField(){ 
                TBNoP.setText("");
                TBNik.setText("");
                TBJenis.setText("");
                TBKeperluan.setText("");
                TBNama.setText("");
                TBJk.setText("");
                TBtptL.setText("");
                TBtglL.setText("");
                TBAgama.setText("");
                TBAlamat.setText("");
    }
}