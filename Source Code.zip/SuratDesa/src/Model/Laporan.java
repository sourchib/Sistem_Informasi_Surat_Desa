package Model;
import static View.Staf.TblLaporan;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author MuChiB
 */
public class Laporan {
    private String query;
    private ResultSet rs;
    private Statement stmt;
   //Menampilkan data permohonan ke tabel surat masuk 
    public String [][]DataLaporan(){
        Koneksi kon = new Koneksi();
        Connection connect=kon.KoneksiDatabase();
        String data [][]=null; 
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("No");
        tbl.addColumn("No Permohonan");
        tbl.addColumn("Surat");
        tbl.addColumn("No NIK");
        tbl.addColumn("Tgl Buat");
        tbl.addColumn("Keperluan");
        TblLaporan.setModel(tbl);
        try{
            stmt=connect.createStatement();
            query="SELECT id_buat, no_permohonan, jenis_surat, nik, tgl_buat, keperluan "
                    + "FROM tb_buatsurat;";
            rs=stmt.executeQuery(query);
            while (rs.next()){
                tbl.addRow(new Object[]{
                    rs.getString("id_buat"),
                    rs.getString("no_permohonan"),
                    rs.getString("jenis_surat"),
                    rs.getString("nik"),
                    rs.getString("tgl_buat"),
                    rs.getString("keperluan"),                    
                });
            }
            stmt.close();
            connect.close();
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Data Gagal ditampilkan");
        }
        return data;
    } 
        public void HapusData() {
        Koneksi koneksi = new Koneksi();
        Connection connection = koneksi.KoneksiDatabase();
        try {
            stmt = connection.createStatement();
            query = "DELETE FROM tb_buatsurat WHERE id_buat";
            stmt.executeUpdate(query);
            stmt.close();
            connection.close();
        } catch (SQLException e) {
            System.out.println("Error : " + e.getMessage());
        }
    } 
    
    public void AutoID() {
        Koneksi koneksi = new Koneksi();
        Connection connection = koneksi.KoneksiDatabase();
        try {
            stmt = connection.createStatement();
            query = "ALTER TABLE tb_buatsurat AUTO_INCREMENT=1";
            stmt.executeUpdate(query);
            stmt.close();
            connection.close();
        } catch (SQLException e) {
            System.out.println("Error : " + e.getMessage());
        }
    }
}
