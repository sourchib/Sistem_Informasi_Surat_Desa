/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import static View.Staf.TBNoP;
import java.io.File;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
/**
 *
 * @author MuChiB
 */
public class IReport {
    private String query;
    private ResultSet rs;
    private Statement stmt;
    JasperReport jasperReport;
    JasperDesign jasperdesign;
    JasperPrint jasperPrint;
    //    Cetak Surat
    public void CetakSurat() {
        
        Koneksi koneksi = new Koneksi();
        Connection connection = koneksi.KoneksiDatabase();
        try {
//            File file = new File("src/Ireport/surat.jrxml");
            InputStream file = getClass().getResourceAsStream("/Ireport/surat.jrxml");
            jasperdesign = JRXmlLoader.load(file);
            jasperReport = JasperCompileManager.compileReport(jasperdesign);
            Map parameter = new HashMap();
            parameter.put("no", TBNoP.getText());
            jasperPrint =  JasperFillManager.fillReport(jasperReport,parameter,connection);
            JasperViewer.viewReport(jasperPrint, false);
        } catch (JRException e) {
            System.out.println(e);
        }
    }
    
    //    Cetak Laporan
    public void CetakLaporan() {
        
        Koneksi koneksi = new Koneksi();
        Connection connection = koneksi.KoneksiDatabase();
        try {
//            File file = new File("src/Ireport/laporan.jrxml");
            InputStream file = getClass().getResourceAsStream("/Ireport/laporan.jrxml");
            jasperdesign = JRXmlLoader.load(file);
            jasperReport = JasperCompileManager.compileReport(jasperdesign);
            jasperPrint = JasperFillManager.fillReport(jasperReport, null,connection);
            JasperViewer.viewReport(jasperPrint, false);
        } catch (JRException e) {
            System.out.println(e);
        }
    }
}