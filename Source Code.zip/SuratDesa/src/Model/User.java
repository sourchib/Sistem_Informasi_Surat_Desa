package Model;
import View.Penduduk;
import View.Staf;
import java.sql.*;
/**
 *
 * @author MuChiB
 */
public class User {
    private String query;
    private ResultSet rs;
    private Statement stmt;
//    get username password
    public int CekUser(String nik, String password){
        Koneksi kon = new Koneksi();
        Connection connect = kon.KoneksiDatabase();
        int data=0;
        try{
            stmt=connect.createStatement();
            query="SELECT COUNT(id_user) FROM user where nik='"+nik+"'"
                    + " and password='"+password+"'";
            rs=stmt.executeQuery(query);
            while(rs.next()){
                data=rs.getInt(1);
            }
            stmt.close();
            connect.close();
        }catch(SQLException ex){
            System.out.println("Error : " +ex.getMessage());            
        }
        return data;
    }
    public int GetIdUser(String nik, String password){
        Koneksi kon = new Koneksi();
        Connection connect = kon.KoneksiDatabase();
        int data=0;
        try{
            stmt=connect.createStatement();
            query="SELECT * FROM user where nik='"+nik+"' "
                    + " and password='"+password+"' ";
            rs = stmt.executeQuery(query);            
            if (rs.next()) {
                if (rs.getString("id_role").equals("1")) {
                    Staf s = new Staf();
//                    s.setLocationRelativeTo(null);
                    s.setVisible(true);
                }else if (rs.getString("id_role").equals("2")){
                    Penduduk p = new Penduduk();
                    p.setVisible(true);
//                    p.setLocationRelativeTo(null);                    
                }
            }
            while(rs.next()){
                data=rs.getInt(1);
            }
            stmt.close();
            connect.close();
        }catch (SQLException ex){
            System.out.println("Error : "+ex.getMessage());
        }
        return data;
    }
}
