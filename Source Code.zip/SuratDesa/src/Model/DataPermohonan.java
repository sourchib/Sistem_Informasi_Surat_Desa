package Model;
import View.Login;
import java.sql.*;
import View.Penduduk;
import static View.Penduduk.CJSurat;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
/**
 *
 * @author MuChiB
 */
public class DataPermohonan {
    private String query;
    private ResultSet rs;
    private Statement stmt;        
//    Insert Master data..
    public void SendData(String surat, int nik, String nama, String jk, String keperluan) {
        Koneksi koneksi = new Koneksi();
        Connection connection = koneksi.KoneksiDatabase();
        try {
            stmt = connection.createStatement();
            query = "INSERT INTO tb_permohonan (jenis_surat, nik, nama, kelamin, keperluan)"
                    + "VALUES ('"+surat+"', '"+nik+"', '"+ nama +"', '"+ jk +"', '"+keperluan+"')";
            stmt.executeUpdate(query);            
            stmt.close();
            connection.close();
            JOptionPane.showMessageDialog(null,"Surat Permohonan Terkirim");             
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"Surat Permohonan Tidak Terkirim","NIK SALAH", JOptionPane.INFORMATION_MESSAGE);            
            Penduduk.TNik.setText("");
            Penduduk.TNama.setText("");
            Penduduk.TKeperluan.setText("");
        }
    }    
       
    public void ListCombo(){  
         Koneksi kon = new Koneksi();
         Connection connect=kon.KoneksiDatabase();
         try{
            query="SELECT * FROM tb_jenissurat";
            stmt=connect.prepareStatement(query);
            rs=stmt.executeQuery(query);
            CJSurat.addItem("PILIH");
            while (rs.next()) {                
                CJSurat.addItem(rs.getString("jenis_surat"));
            }
            rs.last();
            int jumlahdata = rs.getRow();
            rs.first();
            stmt.close();
            connect.close();
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Data Gagal ditampilkan");
        }
    }
}