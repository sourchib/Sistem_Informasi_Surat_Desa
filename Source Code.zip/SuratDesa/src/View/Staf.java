package View;
import Model.BuatSurat;
import Model.IReport;
import Model.DataPenduduk;
import Model.Laporan;
import Model.MenuPanel;
import Model.SuratMasuk;
import com.placeholder.PlaceHolder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/*
 *
 * @author MuChiB
 */
public class Staf extends javax.swing.JFrame {      
//    TABEL Untuk Data penduduk//
    int baris = 0;
    static Object[] kolom = {"No","Nik", "Nama", "Kelamin", "Agama", "Tempat Lahir", "Tangal Lahir", "Alamat", "Pendidikan", "Status,", "RT", "RW"};
    public DefaultTableModel tbl  = new DefaultTableModel(kolom, baris);
    MenuPanel panel = new MenuPanel();
    /**
     * Creates new form Master
     */
    public Staf() {   
        SuratMasuk acc = new SuratMasuk();
        initComponents();
        panel.initPanelSurat();
        panel.setMenuStaf();
        TotSurat.setText(""+acc.TotSuratMasuk());
        acc.SuratMasuk();
        PlaceHolder cari = new PlaceHolder(TCari, " Cari NIK");
    } 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Utama = new javax.swing.JPanel();
        Header = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        Sidebar = new javax.swing.JPanel();
        BtnSurat = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        BtnData = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        BtnPelayan = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        BtnLaporan = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        BtnKeluar = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        Contents = new javax.swing.JPanel();
        SuratMasuk = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        TotSurat = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        TblSuratMasuk = new javax.swing.JTable();
        DataPenduduk = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TblData = new javax.swing.JTable();
        TCari = new javax.swing.JTextField();
        BtnCari = new javax.swing.JButton();
        BtnEdit = new javax.swing.JButton();
        BtnHapus = new javax.swing.JButton();
        BtnTambah = new javax.swing.JButton();
        jLabel22 = new javax.swing.JLabel();
        TotPenduduk = new javax.swing.JLabel();
        Laporan = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        TblLaporan = new javax.swing.JTable();
        BtnCetakLaporan = new javax.swing.JButton();
        Pelayanan = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        TBNama = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        TBJenis = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        TBtptL = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        TBtglL = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        TBAlamat = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        BtnCetakSurat = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        TBNoP = new javax.swing.JTextField();
        TBJk = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        TBKeperluan = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        TBAgama = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        TBTgl = new com.toedter.calendar.JDateChooser();
        TBNik = new javax.swing.JTextField();
        Footer = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        Utama.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Header.setBackground(new java.awt.Color(102, 153, 255));
        Header.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("SansSerif", 0, 28)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 51, 51));
        jLabel2.setText("SISTEM INFORMASI SURAT DESA");
        Header.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 10, -1, 30));

        jLabel3.setFont(new java.awt.Font("SansSerif", 1, 20)); // NOI18N
        jLabel3.setText("DESA BENCE KECAMATAN GARUM KABUPATEN BLITAR");
        Header.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 56, -1, 20));

        jLabel4.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel4.setText("Jl. Raya Bence Garum Blitar Kode Pos 66182 ");
        Header.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 90, -1, 20));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/logo_kab.png"))); // NOI18N
        Header.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 100, 100));

        Utama.add(Header, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 920, 130));

        Sidebar.setBackground(new java.awt.Color(153, 153, 153));
        Sidebar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        BtnSurat.setBackground(new java.awt.Color(204, 204, 204));
        BtnSurat.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        BtnSurat.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnSurat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnSuratMouseClicked(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("SansSerif", 1, 17)); // NOI18N
        jLabel7.setText("SURAT MASUK");

        javax.swing.GroupLayout BtnSuratLayout = new javax.swing.GroupLayout(BtnSurat);
        BtnSurat.setLayout(BtnSuratLayout);
        BtnSuratLayout.setHorizontalGroup(
            BtnSuratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BtnSuratLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel7)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        BtnSuratLayout.setVerticalGroup(
            BtnSuratLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BtnSuratLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Sidebar.add(BtnSurat, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 160, -1));

        BtnData.setBackground(new java.awt.Color(204, 204, 204));
        BtnData.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        BtnData.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnData.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnDataMouseClicked(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 17)); // NOI18N
        jLabel1.setText("DATA PENDUDUK");

        javax.swing.GroupLayout BtnDataLayout = new javax.swing.GroupLayout(BtnData);
        BtnData.setLayout(BtnDataLayout);
        BtnDataLayout.setHorizontalGroup(
            BtnDataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BtnDataLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        BtnDataLayout.setVerticalGroup(
            BtnDataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BtnDataLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );

        Sidebar.add(BtnData, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 160, -1));

        BtnPelayan.setBackground(new java.awt.Color(204, 204, 204));
        BtnPelayan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        BtnPelayan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnPelayan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnPelayanMouseClicked(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("SansSerif", 1, 17)); // NOI18N
        jLabel6.setText("PELAYANAN");

        javax.swing.GroupLayout BtnPelayanLayout = new javax.swing.GroupLayout(BtnPelayan);
        BtnPelayan.setLayout(BtnPelayanLayout);
        BtnPelayanLayout.setHorizontalGroup(
            BtnPelayanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BtnPelayanLayout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(28, 28, 28))
        );
        BtnPelayanLayout.setVerticalGroup(
            BtnPelayanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BtnPelayanLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Sidebar.add(BtnPelayan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 160, -1));

        BtnLaporan.setBackground(new java.awt.Color(204, 204, 204));
        BtnLaporan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        BtnLaporan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnLaporan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnLaporanMouseClicked(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("SansSerif", 1, 17)); // NOI18N
        jLabel8.setText("LAPORAN");

        javax.swing.GroupLayout BtnLaporanLayout = new javax.swing.GroupLayout(BtnLaporan);
        BtnLaporan.setLayout(BtnLaporanLayout);
        BtnLaporanLayout.setHorizontalGroup(
            BtnLaporanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BtnLaporanLayout.createSequentialGroup()
                .addContainerGap(41, Short.MAX_VALUE)
                .addComponent(jLabel8)
                .addGap(37, 37, 37))
        );
        BtnLaporanLayout.setVerticalGroup(
            BtnLaporanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BtnLaporanLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Sidebar.add(BtnLaporan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 280, 160, -1));

        BtnKeluar.setBackground(new java.awt.Color(204, 204, 204));
        BtnKeluar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        BtnKeluar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnKeluar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnKeluarMouseClicked(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("SansSerif", 1, 17)); // NOI18N
        jLabel10.setText("KELUAR");

        javax.swing.GroupLayout BtnKeluarLayout = new javax.swing.GroupLayout(BtnKeluar);
        BtnKeluar.setLayout(BtnKeluarLayout);
        BtnKeluarLayout.setHorizontalGroup(
            BtnKeluarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BtnKeluarLayout.createSequentialGroup()
                .addContainerGap(46, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addGap(43, 43, 43))
        );
        BtnKeluarLayout.setVerticalGroup(
            BtnKeluarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BtnKeluarLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addContainerGap())
        );

        Sidebar.add(BtnKeluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 360, 159, -1));

        Utama.add(Sidebar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 160, 450));

        Contents.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Contents.setLayout(new java.awt.CardLayout());

        SuratMasuk.setBackground(new java.awt.Color(204, 204, 255));
        SuratMasuk.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        SuratMasuk.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel14.setText("SURAT MASUK DATA PERMOHONAN PENDUDUK");
        SuratMasuk.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 21, -1, -1));

        jLabel24.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel24.setText("Total Surat Masuk : ");
        SuratMasuk.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 400, -1, -1));

        TotSurat.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        SuratMasuk.add(TotSurat, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 403, 50, 20));

        TblSuratMasuk.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TblSuratMasuk.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        TblSuratMasuk.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No Permohonan", "Surat Keterangan", "NIK", "Keperluan"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TblSuratMasuk.setGridColor(new java.awt.Color(204, 204, 255));
        jScrollPane4.setViewportView(TblSuratMasuk);

        SuratMasuk.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 660, 320));

        Contents.add(SuratMasuk, "card5");

        DataPenduduk.setBackground(new java.awt.Color(204, 204, 255));
        DataPenduduk.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        DataPenduduk.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TblData.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TblData.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        TblData.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Nik", "Nama", "Kelamin", "Agama", "Tempat Lahir", "Tangal Lahir", "Alamat", "Pendidikan", "Status", "Rt", "Rw"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TblData.setGridColor(new java.awt.Color(204, 204, 255));
        jScrollPane1.setViewportView(TblData);

        DataPenduduk.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 62, 680, 320));
        DataPenduduk.add(TCari, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 180, 30));

        BtnCari.setBackground(new java.awt.Color(204, 204, 204));
        BtnCari.setText("Cari");
        BtnCari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCariActionPerformed(evt);
            }
        });
        DataPenduduk.add(BtnCari, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 10, 80, 30));

        BtnEdit.setBackground(new java.awt.Color(204, 204, 204));
        BtnEdit.setText("Edit");
        BtnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnEditActionPerformed(evt);
            }
        });
        DataPenduduk.add(BtnEdit, new org.netbeans.lib.awtextra.AbsoluteConstraints(218, 398, 70, 29));

        BtnHapus.setBackground(new java.awt.Color(204, 204, 204));
        BtnHapus.setText("Hapus");
        BtnHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnHapusActionPerformed(evt);
            }
        });
        DataPenduduk.add(BtnHapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(123, 398, 69, 29));

        BtnTambah.setBackground(new java.awt.Color(204, 204, 204));
        BtnTambah.setText("Tambah");
        BtnTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnTambahActionPerformed(evt);
            }
        });
        DataPenduduk.add(BtnTambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 398, -1, 29));

        jLabel22.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel22.setText("Total Data Penduduk :");
        DataPenduduk.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 20, -1, -1));

        TotPenduduk.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        DataPenduduk.add(TotPenduduk, new org.netbeans.lib.awtextra.AbsoluteConstraints(646, 20, 30, 24));

        Contents.add(DataPenduduk, "card3");

        Laporan.setBackground(new java.awt.Color(204, 204, 255));
        Laporan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Laporan.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        Laporan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel15.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel15.setText("LAPORAN AGENDA SURAT KELUAR");
        Laporan.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 30, -1, -1));

        TblLaporan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(TblLaporan);

        Laporan.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(48, 75, 611, 302));

        BtnCetakLaporan.setText("Cetak");
        BtnCetakLaporan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCetakLaporanActionPerformed(evt);
            }
        });
        Laporan.add(BtnCetakLaporan, new org.netbeans.lib.awtextra.AbsoluteConstraints(48, 395, 72, 32));

        Contents.add(Laporan, "card6");

        Pelayanan.setBackground(new java.awt.Color(204, 204, 255));
        Pelayanan.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel11.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel11.setText("PEMBUATAN SURAT KETERANGAN");

        jLabel12.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel12.setText("Jenis Surat");

        jLabel13.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel13.setText("No Permohon");

        jLabel16.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel16.setText("Nama");

        jLabel17.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel17.setText("Tempat Lahir");

        jLabel18.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel18.setText("Tangal Lahir");

        jLabel19.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel19.setText("Agama");

        jLabel21.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel21.setText("NIK");

        BtnCetakSurat.setText("Cetak");
        BtnCetakSurat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCetakSuratActionPerformed(evt);
            }
        });

        jLabel25.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel25.setText("Tgl Buat");

        TBNoP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                TBNoPKeyReleased(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel20.setText("Jenis Kelamin");

        jLabel26.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel26.setText("Keperluan");

        jLabel23.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel23.setText("Alamat");

        javax.swing.GroupLayout PelayananLayout = new javax.swing.GroupLayout(Pelayanan);
        Pelayanan.setLayout(PelayananLayout);
        PelayananLayout.setHorizontalGroup(
            PelayananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PelayananLayout.createSequentialGroup()
                .addGap(210, 210, 210)
                .addComponent(jLabel11))
            .addGroup(PelayananLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel13)
                .addGap(18, 18, 18)
                .addComponent(TBNoP, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(78, 78, 78)
                .addComponent(jLabel16)
                .addGap(65, 65, 65)
                .addComponent(TBNama, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(PelayananLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70)
                .addComponent(TBNik, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(78, 78, 78)
                .addComponent(jLabel20)
                .addGap(14, 14, 14)
                .addComponent(TBJk, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(PelayananLayout.createSequentialGroup()
                .addGap(399, 399, 399)
                .addComponent(jLabel23)
                .addGap(57, 57, 57)
                .addComponent(TBAlamat, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(PelayananLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(BtnCetakSurat, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(PelayananLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(PelayananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addComponent(jLabel26)
                    .addComponent(jLabel25))
                .addGap(34, 34, 34)
                .addGroup(PelayananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PelayananLayout.createSequentialGroup()
                        .addComponent(TBJenis, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(78, 78, 78)
                        .addComponent(jLabel17)
                        .addGap(16, 16, 16)
                        .addComponent(TBtptL, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PelayananLayout.createSequentialGroup()
                        .addGroup(PelayananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(TBTgl, javax.swing.GroupLayout.DEFAULT_SIZE, 183, Short.MAX_VALUE)
                            .addComponent(TBKeperluan))
                        .addGroup(PelayananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PelayananLayout.createSequentialGroup()
                                .addGap(77, 77, 77)
                                .addComponent(jLabel18)
                                .addGap(20, 20, 20)
                                .addComponent(TBtglL, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PelayananLayout.createSequentialGroup()
                                .addGap(78, 78, 78)
                                .addComponent(jLabel19)
                                .addGap(55, 55, 55)
                                .addComponent(TBAgama, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))))))
        );
        PelayananLayout.setVerticalGroup(
            PelayananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PelayananLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel11)
                .addGap(33, 33, 33)
                .addGroup(PelayananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PelayananLayout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel13))
                    .addGroup(PelayananLayout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(TBNoP, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PelayananLayout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jLabel16))
                    .addComponent(TBNama, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(PelayananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PelayananLayout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(jLabel21))
                    .addGroup(PelayananLayout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(TBNik, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PelayananLayout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel20))
                    .addComponent(TBJk, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(PelayananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PelayananLayout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addGroup(PelayananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(TBJenis, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(PelayananLayout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel17))
                    .addComponent(TBtptL, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(PelayananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PelayananLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(PelayananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TBtglL, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(PelayananLayout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addGroup(PelayananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel26)
                                    .addComponent(jLabel18)))))
                    .addGroup(PelayananLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(TBKeperluan, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(PelayananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PelayananLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(jLabel25))
                    .addComponent(TBTgl, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(PelayananLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(jLabel19))
                    .addGroup(PelayananLayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(TBAgama, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(19, 19, 19)
                .addGroup(PelayananLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PelayananLayout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel23))
                    .addComponent(TBAlamat, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addComponent(BtnCetakSurat, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        Contents.add(Pelayanan, "card4");

        Utama.add(Contents, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, 720, 450));

        Footer.setBackground(new java.awt.Color(102, 153, 255));
        Footer.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setText("@Power By Muchammad Muchib Zainul Fikry");
        Footer.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        Utama.add(Footer, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 610, 920, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Utama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Utama, javax.swing.GroupLayout.PREFERRED_SIZE, 646, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BtnSuratMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnSuratMouseClicked
        panel.setActiveMenu(BtnSurat);        
        panel.setActivePanel(Contents,SuratMasuk);  
        SuratMasuk acc = new SuratMasuk();
        TotSurat.setText(""+acc.TotSuratMasuk());
        acc.SuratMasuk();
    }//GEN-LAST:event_BtnSuratMouseClicked

    private void BtnPelayanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnPelayanMouseClicked
        panel.setActiveMenu(BtnPelayan);
        TBNama.setEditable(false);
        TBNik.setEditable(false);
        TBJk.setEditable(false);
        TBtptL.setEditable(false);
        TBtglL.setEditable(false);
        TBAgama.setEditable(false);
        TBAgama.setEditable(false);
        TBAlamat.setEditable(false); 
        TBKeperluan.setEditable(false);
        TBJenis.setEditable(false);
        Date tgl = new Date();
        TBTgl.setDate(tgl);
        TBTgl.setFocusCycleRoot(false);
        panel.setActivePanel(Contents,Pelayanan);
    }//GEN-LAST:event_BtnPelayanMouseClicked

    private void BtnLaporanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnLaporanMouseClicked
        panel.setActiveMenu(BtnLaporan);
        Laporan lapor = new Laporan();
        lapor.DataLaporan();
        panel.setActivePanel(Contents,Laporan);
    }//GEN-LAST:event_BtnLaporanMouseClicked

    private void BtnDataMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnDataMouseClicked
        panel.setActiveMenu(BtnData);
        DataPenduduk DP = new DataPenduduk();
        TotPenduduk.setText(""+DP.TotDataPenduduk());
        panel.setActivePanel(Contents,DataPenduduk);
    }//GEN-LAST:event_BtnDataMouseClicked

    private void BtnKeluarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnKeluarMouseClicked
        panel.setActiveMenu(BtnKeluar);
        this.dispose();
    }//GEN-LAST:event_BtnKeluarMouseClicked

    private void BtnTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnTambahActionPerformed
        TambahData t = new TambahData();
        t.setLocationRelativeTo(null);
        t.setVisible(true); 
        t.pack();
        t.setDefaultCloseOperation(Staf.DISPOSE_ON_CLOSE);
    }//GEN-LAST:event_BtnTambahActionPerformed

    private void BtnCariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCariActionPerformed
        DataPenduduk DP = new DataPenduduk();
        String KataKunci=TCari.getText();
        tbl.getDataVector().removeAllElements();        
        String [][]data=DP.CariPenduduk(KataKunci);
        for (int i = 0; i < data.length; i++) {
            int no=i+1;
            tbl.addRow(new Object[]{no, data[i][0], data[i][1],data[i][2], data[i][3],data[i][4], data[i][5]
                    ,data[i][6], data[i][7],data[i][8], data[i][9], data[i][10]});            
        }
        TblData.setModel(tbl);
        TCari.setText(KataKunci);
    }//GEN-LAST:event_BtnCariActionPerformed

    private void BtnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnEditActionPerformed
        SimpanData simpan = new SimpanData();    
        int index = TblData.getSelectedRow();
        String nik = tbl.getValueAt(index, 1).toString();
        String nama = tbl.getValueAt(index, 2).toString();
        String kelamin= tbl.getValueAt(index, 3).toString();
        if (kelamin.equals("Laki-Laki")) {
            simpan.rbLK.setSelected(true);
            simpan.rbLK.setText(kelamin);
        }else{
            simpan.rbPR.setSelected(true);
            simpan.rbPR.setText(kelamin);
        }
        String agama = tbl.getValueAt(index, 4).toString();
        String Tlahir = "yyyy-MM-dd";
        try {
            java.util.Date ttl = new SimpleDateFormat(Tlahir).parse((String)tbl.getValueAt(index, 6).toString());
            simpan.Ttgl.setDate(ttl);
        } catch (ParseException ex) {
            Logger.getLogger(Staf.class.getName()).log(Level.SEVERE, null, ex);
        }
        String lahir = tbl.getValueAt(index, 5).toString();
        String alamat = tbl.getValueAt(index, 7).toString();
        String pendidikan = tbl.getValueAt(index, 8).toString();
        String status = tbl.getValueAt(index, 9).toString();
        String rt = tbl.getValueAt(index, 10).toString();
        String rw = tbl.getValueAt(index, 11).toString();
        simpan.setLocationRelativeTo(null);
        simpan.setVisible(true); 
        simpan.pack();
        simpan.setDefaultCloseOperation(Staf.DISPOSE_ON_CLOSE);  
        simpan.TNik.setText(nik);
        simpan.TNama.setText(nama);  
        simpan.TAgama.setText(agama);
        simpan.TLahir.setText(lahir);
        simpan.TAlamat.setText(alamat);
        simpan.TPendidikan.setText(pendidikan);
        simpan.TStatus.setText(status);
        simpan.TRt.setText(rt);
        simpan.TRw.setText(rw);
    }//GEN-LAST:event_BtnEditActionPerformed

    private void BtnHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnHapusActionPerformed
        DataPenduduk DP = new DataPenduduk();        
        int Pilihbaris=TblData.getSelectedRow();
        String KodeNIK=tbl.getValueAt(Pilihbaris, 1).toString();        
        DP.HapusData(KodeNIK);
        tbl.removeRow(Pilihbaris);
        JOptionPane.showMessageDialog(this, "Data berhasil dihapus",
                "Pesan Konfirmasi", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_BtnHapusActionPerformed

    private void BtnCetakSuratActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCetakSuratActionPerformed
        IReport cetak = new IReport();
        BuatSurat buat = new BuatSurat();
        int no = Integer.parseInt(TBNoP.getText()); 
        int nik = Integer.parseInt(TBNik.getText());
        String surat =TBJenis.getText();
        String perlu = TBKeperluan.getText();
        String Tlahir = "yyyy-MM-dd";
        SimpleDateFormat fm = new SimpleDateFormat(Tlahir);
        String tgl = String.valueOf(fm.format(TBTgl.getDate()));
        buat.SimpanData(no, nik, surat, tgl, perlu);
        cetak.CetakSurat();
        buat.ClearTextField();
        buat.HapusSuratMasuk(no);
    }//GEN-LAST:event_BtnCetakSuratActionPerformed
    
    private void BtnCetakLaporanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCetakLaporanActionPerformed
        IReport cetak = new IReport();
        Laporan lapor = new Laporan();
        cetak.CetakLaporan();       
        lapor.HapusData();
        lapor.AutoID();
    }//GEN-LAST:event_BtnCetakLaporanActionPerformed

    private void TBNoPKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TBNoPKeyReleased
        BuatSurat buat = new BuatSurat();        
        buat.KeyDataPenduduk();
    }//GEN-LAST:event_TBNoPKeyReleased
    
    public static void DatatoTable(Object [] AddRow){
        DefaultTableModel model = (DefaultTableModel) TblData.getModel();
        model.addRow(AddRow);     
    }    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Staf.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Staf.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Staf.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Staf.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Staf().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnCari;
    private javax.swing.JButton BtnCetakLaporan;
    private javax.swing.JButton BtnCetakSurat;
    public static javax.swing.JPanel BtnData;
    private javax.swing.JButton BtnEdit;
    private javax.swing.JButton BtnHapus;
    public static javax.swing.JPanel BtnKeluar;
    public static javax.swing.JPanel BtnLaporan;
    public static javax.swing.JPanel BtnPelayan;
    public static javax.swing.JPanel BtnSurat;
    private javax.swing.JButton BtnTambah;
    public static javax.swing.JPanel Contents;
    public static javax.swing.JPanel DataPenduduk;
    private javax.swing.JPanel Footer;
    private javax.swing.JPanel Header;
    public static javax.swing.JPanel Laporan;
    public static javax.swing.JPanel Pelayanan;
    private javax.swing.JPanel Sidebar;
    public static javax.swing.JPanel SuratMasuk;
    public static javax.swing.JTextField TBAgama;
    public static javax.swing.JTextField TBAlamat;
    public static javax.swing.JTextField TBJenis;
    public static javax.swing.JTextField TBJk;
    public static javax.swing.JTextField TBKeperluan;
    public static javax.swing.JTextField TBNama;
    public static javax.swing.JTextField TBNik;
    public static javax.swing.JTextField TBNoP;
    private com.toedter.calendar.JDateChooser TBTgl;
    public static javax.swing.JTextField TBtglL;
    public static javax.swing.JTextField TBtptL;
    private javax.swing.JTextField TCari;
    public static javax.swing.JTable TblData;
    public static javax.swing.JTable TblLaporan;
    public static javax.swing.JTable TblSuratMasuk;
    private javax.swing.JLabel TotPenduduk;
    private javax.swing.JLabel TotSurat;
    private javax.swing.JPanel Utama;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    // End of variables declaration//GEN-END:variables
}
